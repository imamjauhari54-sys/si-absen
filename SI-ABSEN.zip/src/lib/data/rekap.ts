import { supabaseAdmin } from "@/lib/supabase/server";
import { formatWaktuWib, todayJakarta } from "@/lib/utils/tanggal";
import { ambilSemua } from "@/lib/utils/ambil-semua";
import { getKelasTapel, getSiswaTapel, tapelUntukBulan, tapelUntukTanggal } from "@/lib/data/riwayat-kelas";
import { getAbsensiSetting } from "@/lib/data/dashboard";
import { ambilNonaktifIds } from "@/lib/data/nonaktif";
import { ambilJedaTapel } from "@/lib/data/jeda";
import { getLiburSet } from "@/lib/data/hari-libur";
import { catatanJedaPortal, ketTidakDihitung, labelJedaBulan } from "@/lib/utils/ket-jeda";
import { ambilMenungguBanyak, ambilMulaiBanyak, getRekapSiswaRentang } from "@/lib/data/rekap-siswa";
import { tapelDariTanggal } from "@/lib/utils/tapel";
import { hitungRekapSiswa, KET_HARI_MENUNGGU, rentangSemester, statusHariSiswa, type StatusHariSiswa } from "@/lib/utils/rekap-siswa";
import {
  labelJedaPada,
  labelKeluar,
  penyebutSiswa,
  perluCekData,
  perluHitungPerSiswa,
  saringSiswaRekap,
} from "@/lib/utils/siswa-harian";
import { keteranganSumber, tentukanSumberAbsen, type SumberAbsen } from "@/lib/utils/sumber-absen";
import type { StatusAbsen } from "@/types";

/** Daftar kelas pada tapel itu (menurut riwayat kelas), untuk dropdown filter Rekap. */
export async function getSemuaKelasRekap(tapel: string): Promise<string[]> {
  return getKelasTapel(tapel);
}

/**
 * Daftar bulan (YYYY-MM) yang ada data absensinya, dipakai di dropdown
 * "reset data per bulan" di halaman Pengaturan. Pakai RPC distinct_bulan_absensi
 * (lihat supabase/migrations/004_optimasi_query.sql) supaya hitungnya di
 * level database (jauh lebih ringan daripada narik seluruh kolom tanggal
 * dari tabel absensi yang bisa puluhan ribu baris). Kalau migrasinya belum
 * dijalankan, otomatis jatuh ke cara lama (tetap dibatasi LIMIT biar nggak
 * sepenuhnya tanpa batas).
 */
export async function getDistinctBulanAbsensi(): Promise<string[]> {
  const { data, error } = await supabaseAdmin.rpc("distinct_bulan_absensi");
  if (!error && data) {
    return (data as { bulan: string }[]).map((r) => r.bulan);
  }

  const { data: rows } = await supabaseAdmin
    .from("absensi")
    .select("tanggal")
    .order("tanggal", { ascending: false })
    .limit(5000);
  const bulanSet = new Set((rows ?? []).map((r) => r.tanggal.slice(0, 7)));
  return Array.from(bulanSet).sort((a, b) => (a < b ? 1 : -1));
}

// ── HARIAN ──────────────────────────────────────────────────────────────

export type StatusHarian = StatusAbsen | "kosong";

/** Kondisi baris SEBELUM edit manual terakhir (yang akan dikembalikan oleh Pulihkan). null = barisnya belum ada. */
export interface SebelumEdit {
  status: StatusAbsen;
  jam_masuk: string | null;
  jam_pulang: string | null;
  keterangan: string | null;
  lampiran: boolean;
}

/** Ada pada baris yang edit manual terakhirnya MASIH bisa dipulihkan sekarang. */
export interface InfoPulihkan {
  /** ID edit yang akan dipulihkan (o_edit_id). Dikirim kembali saat Pulihkan agar yang dipulihkan persis edit yang dilihat pengguna. */
  editId: number;
  dieditOleh: string | null;
  dieditPada: string; // sudah diformat WIB
  batasPulihkan: string; // sudah diformat WIB
  sebelum: SebelumEdit | null;
}

export interface RekapHarianRow {
  id: number;
  name: string;
  class: string;
  /** Mis. "Pindah · 12 Okt 2026" untuk siswa yang sudah keluar; null untuk siswa aktif. */
  labelKeluar: string | null;
  status: StatusHarian;
  /** Tanggal pindah siswa: baris tampil tetapi absensinya tidak dihitung. */
  tidakDihitung?: boolean;
  /** Tanggal ini hari libur: tidak dihitung (catatan yang ada diabaikan), bukan Alpha. */
  libur?: boolean;
  /** Pengajuan izin/sakit orang tua MENUNGGU keputusan untuk tanggal ini: tidak dihitung dan bukan Alpha. */
  menunggu?: boolean;
  /** Siswa belum punya catatan sampai tanggal ini (sebelum catatan pertama di tapel itu): tidak dihitung, bukan Alpha. */
  belumTercatat?: boolean;
  jam_masuk: string | null;
  jam_pulang: string | null;
  keterangan: string | null;
  lampiran: string | null;
  pulihkan: InfoPulihkan | null;
  /** Asal catatan untuk subtext di bawah status ("scan" / "edit guru" / "otomatis"); null = tidak diketahui. */
  sumber: SumberAbsen | null;
  /** Teks tooltip untuk `sumber`. */
  sumberKet: string | null;
}

export interface StatHarian {
  hadir: number;
  terlambat: number;
  izin: number;
  sakit: number;
  alpha: number;
}

/**
 * Port dari query VIEW HARIAN rekap.php: semua siswa (LEFT JOIN absensi),
 * status default 'alpha' kalau tanggal < hari ini, atau 'kosong' kalau
 * hari ini/masa depan dan belum ada record.
 */
export async function getRekapHarian(
  tanggal: string,
  kelasFilter: string,
  opsi: { denganPulihkan?: boolean; denganSumber?: boolean } = {}
): Promise<{ rows: RekapHarianRow[]; stat: StatHarian }> {
  // Siswa & kelasnya diambil dari riwayat kelas pada tapel tanggal ini, bukan students.class,
  // supaya rekap tanggal lama tetap menampilkan kelas yang benar setelah siswa naik kelas.
  const tapel = await tapelUntukTanggal(tanggal);
  const [siswaTapel, jedaMap] = await Promise.all([getSiswaTapel(tapel, kelasFilter), ambilJedaTapel(tapel)]);
  const semua = siswaTapel.map((s) => ({
    id: s.siswa_id,
    name: s.nama,
    class: s.kelas,
    nonaktif_pada: s.nonaktif_pada,
    jeda: jedaMap.get(s.siswa_id) ?? [],
    labelKeluar: labelKeluar(s.alasan_nonaktif, s.nonaktif_pada),
  }));
  const kosongStat: StatHarian = { hadir: 0, terlambat: 0, izin: 0, sakit: 0, alpha: 0 };
  if (semua.length === 0) return { rows: [], stat: kosongStat };

  const idsSemua = semua.map((s) => s.id);
  const [{ data: absenRows }, nonaktifIds, setting] = await Promise.all([
    supabaseAdmin
      .from("absensi")
      .select("siswa_id, status, jam_masuk, jam_pulang, keterangan, lampiran, scan_oleh")
      .eq("tanggal", tanggal)
      .in("siswa_id", idsSemua),
    ambilNonaktifIds(),
    getAbsensiSetting(),
  ]);
  const absenMap = new Map((absenRows ?? []).map((r) => [r.siswa_id, r]));

  // Siswa yang pindah tampil sampai tanggal pindahnya (pada tanggal itu tampil tetapi tidak dihitung), lalu
  // hilang (lihat siswa-harian.ts), supaya jumlahnya cocok dengan Data Siswa dan tanpa alpha palsu.
  const list = saringSiswaRekap(semua, {
    tapelRekap: tapel,
    tapelAktif: setting.tapel,
    nonaktifIds,
    adaAbsenIds: new Set(absenMap.keys()),
    periode: [tanggal],
  });
  if (list.length === 0) return { rows: [], stat: kosongStat };
  const ids = list.map((s) => s.id);
  // Info tombol Pulihkan hanya diminta halaman Rekap (ekspor CSV tidak memerlukannya).
  const pulihkanMap = opsi.denganPulihkan ? await getInfoPulihkan(tanggal, ids) : new Map<number, InfoPulihkan>();
  // Subtext asal catatan hanya dipakai halaman Rekap (bukan ekspor CSV), jadi kueri tambahannya opsional.
  const editMap = opsi.denganSumber ? await getEditManualAktif(tanggal) : new Map<number, EditManualAktif>();

  const today = todayJakarta();
  // Batas awal = catatan pertama siswa pada tapel itu (migrasi 026): hari sebelumnya tidak dihitung. Sama dengan Portal & Bulanan.
  const [mulaiMap, libur, menungguMap] = await Promise.all([
    ambilMulaiBanyak(tapelDariTanggal(tanggal), ids),
    getLiburSet(tanggal, tanggal),
    ambilMenungguBanyak(ids, tanggal, tanggal),
  ]);

  const stat: StatHarian = { hadir: 0, terlambat: 0, izin: 0, sakit: 0, alpha: 0 };
  const rows: RekapHarianRow[] = list.map((s) => {
    const a = absenMap.get(s.id);
    // SATU aturan hitung (utils/rekap-siswa.ts), sama dengan Rekap Bulanan & kartu ringkasan Portal Siswa.
    // "nonaktif" = tanggal pindah/jeda: baris tampil (dengan lencana pada tanggal awal) tetapi tidak dihitung.
    const mulai = mulaiMap.get(s.id) ?? null;
    const hasil = statusHariSiswa(tanggal, {
      today,
      libur,
      absensi: a ? new Map([[tanggal, a.status as string]]) : new Map<string, string>(),
      nonaktifPada: s.nonaktif_pada,
      jeda: s.jeda,
      menunggu: menungguMap.get(s.id),
      mulai,
    });
    const tidakDihitung = hasil === "nonaktif";
    const adaMenunggu = hasil === "menunggu";
    const adaLibur = hasil === "libur";
    // "kosong" karena belum ada catatan pertama (bukan sekadar hari ini yang belum scan): tidak dihitung dan tidak Alpha.
    const belumTercatat = hasil === "kosong" && (mulai === null || tanggal < mulai);
    const status: StatusHarian = hasil === "nonaktif" || hasil === "libur" || hasil === "menunggu" ? "kosong" : (hasil as StatusHarian);
    const tersembunyi = tidakDihitung || adaLibur || belumTercatat || adaMenunggu;
    if (status in stat) stat[status as keyof StatHarian]++;
    // Baris yang TIDAK DIHITUNG (libur, belum tercatat, sesudah pindah/jeda) tidak boleh membocorkan isi catatannya:
    // jam, keterangan, lampiran, asal catatan, dan tombol Pulihkan semuanya disembunyikan. Catatannya sendiri tidak dihapus
    // (muncul kembali bila tanggal libur/pindah diubah). Semua field tampilan diturunkan dari `tampil`, bukan dari `a`.
    const tampil = tersembunyi ? undefined : a;
    // Subtext hanya untuk baris yang benar-benar tercatat (bukan status bawaan alpha/kosong).
    const edit = tampil ? editMap.get(s.id) : undefined;
    const sumber = opsi.denganSumber && tampil ? tentukanSumberAbsen({ scanOleh: tampil.scan_oleh, adaEditManual: !!edit }) : null;
    return {
      id: s.id,
      name: s.name,
      class: s.class,
      labelKeluar: labelJedaPada(s.jeda, tanggal) ?? s.labelKeluar,
      status,
      tidakDihitung,
      ...(adaLibur ? { libur: true } : {}),
      ...(adaMenunggu ? { menunggu: true } : {}),
      ...(belumTercatat ? { belumTercatat: true } : {}),
      jam_masuk: tampil?.jam_masuk ?? null,
      jam_pulang: tampil?.jam_pulang ?? null,
      keterangan: tampil?.keterangan ?? null,
      lampiran: tampil?.lampiran ?? null,
      pulihkan: tersembunyi ? null : (pulihkanMap.get(s.id) ?? null),
      sumber,
      sumberKet: keteranganSumber(sumber, { scanOleh: tampil?.scan_oleh, editorNama: edit?.editorNama, dieditAt: edit?.dieditAt }),
    };
  });

  return { rows, stat };
}

interface EditManualAktif {
  editorNama: string | null;
  dieditAt: string;
}

/**
 * Siswa yang punya edit manual pada `tanggal` yang BELUM dipulihkan (edit terbaru per siswa).
 * Tidak dibatasi masa pulihkan: ini jejak audit, bukan tombol. Kalau tabelnya belum ada (migrasi 019
 * belum dijalankan) hasilnya kosong dan halaman tetap berfungsi.
 */
async function getEditManualAktif(tanggal: string): Promise<Map<number, EditManualAktif>> {
  const hasil = new Map<number, EditManualAktif>();
  try {
    const rows = await ambilSemua<{ siswa_id: number; editor_nama: string | null; diedit_at: string }>((dari, sampai) =>
      supabaseAdmin
        .from("absensi_edit_manual")
        .select("siswa_id, editor_nama, diedit_at")
        .eq("tanggal", tanggal)
        .is("dipulihkan_at", null)
        .order("id", { ascending: true })
        .range(dari, sampai)
    );
    // urut naik: yang terakhir (id terbesar) menimpa, jadi edit terbaru yang tersimpan
    for (const r of rows) hasil.set(r.siswa_id, { editorNama: r.editor_nama, dieditAt: r.diedit_at });
  } catch (e) {
    console.error("[getEditManualAktif]", e);
  }
  return hasil;
}

/**
 * Siswa yang edit manual terakhirnya pada `tanggal` masih bisa dipulihkan. Syaratnya diputuskan di
 * database (fungsi daftar_bisa_pulihkan, migrasi 019) supaya identik dengan yang dicek saat Pulihkan.
 * Kalau migrasinya belum dijalankan, tombol Pulihkan tidak muncul dan halaman tetap berfungsi.
 */
async function getInfoPulihkan(tanggal: string, siswaIds: number[]): Promise<Map<number, InfoPulihkan>> {
  const hasil = new Map<number, InfoPulihkan>();
  const { data, error } = await supabaseAdmin.rpc("daftar_bisa_pulihkan", { p_tanggal: tanggal, p_siswa_ids: siswaIds });
  if (error) {
    console.error("[getInfoPulihkan]", error.message);
    return hasil;
  }
  type Baris = {
    o_siswa_id: number;
    o_edit_id: number;
    o_diedit_at: string;
    o_editor_nama: string | null;
    o_batas: string;
    o_sebelum: Record<string, string | null> | null;
  };
  for (const r of (data ?? []) as Baris[]) {
    // Tanpa ID edit yang valid tombol Pulihkan tidak boleh muncul (gagal tertutup).
    const editId = Number(r.o_edit_id);
    if (!Number.isSafeInteger(editId) || editId <= 0) {
      console.error("[getInfoPulihkan] o_edit_id tidak valid:", r.o_edit_id);
      continue;
    }
    const j = r.o_sebelum;
    hasil.set(r.o_siswa_id, {
      editId,
      dieditOleh: r.o_editor_nama,
      dieditPada: formatWaktuWib(r.o_diedit_at),
      batasPulihkan: formatWaktuWib(r.o_batas),
      sebelum: j
        ? {
            status: j.status as StatusAbsen,
            jam_masuk: j.jam_masuk ?? null,
            jam_pulang: j.jam_pulang ?? null,
            keterangan: j.keterangan ?? null,
            lampiran: !!j.lampiran,
          }
        : null,
    });
  }
  return hasil;
}

// ── BULANAN ─────────────────────────────────────────────────────────────

/** "nonaktif" = pada tanggal pindah dan sesudahnya (tanggal >= nonaktif_pada); tidak dihitung, apa pun record-nya. */
/** Status sel Rekap Bulanan = status hari menurut fungsi hitung bersama (utils/rekap-siswa.ts). */
export type StatusBulanan = StatusHariSiswa;

export interface RekapBulananRow {
  id: number;
  nama: string;
  kelas: string;
  labelKeluar: string | null;
  /** Lencana jeda pada bulan ini, mis. "Jeda 15 Agu 2026 – 9 Sep 2026"; null bila tidak ada. Menjelaskan sel "×". */
  jedaLabel: string | null;
  hadir: number;
  terlambat: number;
  izin: number;
  sakit: number;
  alpha: number;
  d: Record<string, StatusBulanan>; // tanggal -> status
  /** Jumlah hari berstatus Menunggu persetujuan pengajuan (tidak dihitung). */
  menunggu: number;
  /** Penjelasan sel "×"/"M" (tanggal -> teks): jeda, sudah pindah, atau menunggu persetujuan. Hanya berisi sel yang tidak dihitung. */
  ket: Record<string, string>;
}

/** Daftar tanggal Senin-Sabtu (exclude Minggu) dalam satu bulan kalender. */
export function daftarTanggalBulan(bulanYYYYMM: string): string[] {
  const [y, m] = bulanYYYYMM.split("-").map(Number);
  const dates: string[] = [];
  const cur = new Date(Date.UTC(y, m - 1, 1));
  while (cur.getUTCMonth() === m - 1) {
    if (cur.getUTCDay() !== 0) dates.push(cur.toISOString().slice(0, 10)); // exclude Minggu
    cur.setUTCDate(cur.getUTCDate() + 1);
  }
  return dates;
}

// ── HISTORY (AKUMULASI SEMESTER) ──────────────────────────────────────

// Hari libur (tabel hari_libur) dan hari Minggu TIDAK dihitung sebagai hari
// efektif, dan record absensi pada tanggal itu diabaikan — walaupun libur baru
// dicatat setelah absensi hari itu terlanjur ada. Agregasi dilakukan di
// database (lihat migrasi 013) supaya tidak terkena batas 1000 baris PostgREST.
async function hitungHariEfektif(tapel: string, semester: string): Promise<number> {
  const { data, error } = await supabaseAdmin.rpc("hari_efektif", { p_tapel: tapel, p_semester: semester });
  if (error) throw new Error(`Gagal menghitung hari efektif: ${error.message}`);
  return Number(data ?? 0);
}

/**
 * Penyebut persentase PER SISWA = hari yang dihitung untuk siswa itu pada semester tsb (hari_dihitung_siswa,
 * migrasi 025): hari efektif dikurangi hari sesudah tanggal pindah dan hari jeda. Siswa tanpa pindah/jeda =
 * hari efektif penuh. Satu aturan yang sama dengan rekap_history_siswa (pembilang) dan rekap harian/bulanan.
 * Siswa yang tidak muncul di hasil = 0 hari dihitung.
 */
async function petaHariDihitung(tapel: string, semester: string, ids: number[]): Promise<Map<number, number>> {
  const peta = new Map<number, number>();
  if (ids.length === 0) return peta;
  const { data, error } = await supabaseAdmin.rpc("hari_dihitung_siswa", { p_tapel: tapel, p_semester: semester, p_ids: ids });
  if (error) throw new Error(`Gagal menghitung hari terhitung per siswa: ${error.message}. Pastikan migrasi 025 sudah dijalankan.`);
  for (const r of (data ?? []) as { siswa_id: number; hari: number }[]) peta.set(r.siswa_id, Number(r.hari));
  return peta;
}

async function ambilAgregatSemester(
  tapel: string,
  semester: string,
  ids: number[]
): Promise<Map<number, Record<string, number>>> {
  const { data, error } = await supabaseAdmin.rpc("rekap_history_siswa", {
    p_tapel: tapel,
    p_semester: semester,
    p_ids: ids,
  });
  if (error) throw new Error(`Gagal mengambil rekap semester: ${error.message}`);
  const peta = new Map<number, Record<string, number>>();
  for (const r of (data ?? []) as { siswa_id: number; status: string; jumlah: number }[]) {
    if (!peta.has(r.siswa_id)) peta.set(r.siswa_id, {});
    peta.get(r.siswa_id)![r.status] = Number(r.jumlah);
  }
  return peta;
}

export interface RekapHistoryRow {
  nama: string;
  kelas: string;
  nisn: string | null;
  /** Mis. "Pindah · 12 Okt 2026" untuk siswa yang sudah keluar; null untuk siswa aktif. */
  labelKeluar: string | null;
  hadir: number;
  telat: number;
  izin: number;
  sakit: number;
  alpha: number;
  persen: number;
}

/**
 * Port dari rekap_history.php: akumulasi total H/T/I/S/A per siswa selama
 * satu tapel+semester penuh, dibanding jumlah hari efektif (hari unik yang
 * punya record absensi pada periode tsb).
 */
export interface RekapHistoryPageResult {
  rows: RekapHistoryRow[];
  totalHariEfektif: number;
  totalSiswa: number;
  totalPages: number;
  page: number;
}

/**
 * Versi paginasi sungguhan dari getRekapHistory() di atas — dipakai khusus
 * untuk halaman /rekap-history. Bedanya: siswa diambil per halaman lewat
 * .range(), lalu absensi cuma di-agregasi untuk siswa di halaman itu saja
 * (bukan seluruh siswa hasil filter kelas). Untuk kebutuhan export
 * CSV/Excel (yang memang butuh semua baris sekaligus), tetap pakai
 * getRekapHistory() yang asli.
 */
export async function getRekapHistoryPage(
  tapel: string,
  semester: string,
  kelasFilter: string,
  page: number,
  pageSize: number
): Promise<RekapHistoryPageResult> {
  if (!tapel || !semester) return { rows: [], totalHariEfektif: 0, totalSiswa: 0, totalPages: 1, page: 1 };

  const totalHariEfektif = await hitungHariEfektif(tapel, semester);

  // Daftar siswa = siswa yang punya riwayat kelas di tapel ini (kelasnya pada tapel itu). Daftar
  // ringan (id, nama, kelas, nisn) diambil seluruhnya lalu dipotong per halaman di sini; yang
  // berat (agregat absensi) tetap hanya dihitung untuk siswa di halaman yang tampil.
  const [semuaDasar, jedaMap] = await Promise.all([getSiswaTapel(tapel, kelasFilter), ambilJedaTapel(tapel)]);
  // Di tapel aktif, siswa lulus/pindah hanya ikut kalau punya absensi pada semester ini. Agregat
  // dihitung dulu hanya untuk mereka (jumlahnya kecil) supaya total & paginasi tetap benar.
  const [nonaktifIds, setting] = await Promise.all([ambilNonaktifIds(), getAbsensiSetting()]);
  const dasar = semuaDasar.map((s) => ({ ...s, id: s.siswa_id, jeda: jedaMap.get(s.siswa_id) ?? [] }));
  const opsiSaring = { tapelRekap: tapel, tapelAktif: setting.tapel, nonaktifIds };
  const kandidat = dasar.filter((s) => perluCekData(s, opsiSaring)).map((s) => s.id);
  const agregatKandidat =
    kandidat.length > 0 ? await ambilAgregatSemester(tapel, semester, kandidat) : new Map<number, Record<string, number>>();
  const semuaSiswa = saringSiswaRekap(dasar, { ...opsiSaring, adaAbsenIds: new Set(agregatKandidat.keys()), semesterRekap: semester });
  const totalSiswa = semuaSiswa.length;
  const totalPages = Math.max(1, Math.ceil(totalSiswa / pageSize));
  const pageAman = Math.min(Math.max(1, page), totalPages);
  const from = (pageAman - 1) * pageSize;
  // PENTING: sebarkan seluruh field (`...s`) agar `jeda` dan `nonaktif_pada` tetap ada untuk penyebut per siswa.
  const list = semuaSiswa.slice(from, from + pageSize).map((s) => ({
    ...s,
    name: s.nama,
    class: s.kelas,
    labelKeluar: labelKeluar(s.alasan_nonaktif, s.nonaktif_pada),
  }));
  if (list.length === 0) return { rows: [], totalHariEfektif, totalSiswa, totalPages, page: pageAman };

  const ids = list.map((s) => s.id);
  const rs = rentangSemester(tapel, semester);
  const menungguMap = rs ? await ambilMenungguBanyak(ids, rs.dari, rs.sampai) : new Map<number, Set<string>>();
  // `menunggu` = siswa punya hari Menunggu persetujuan pengajuan di semester ini: penyebutnya ikut berkurang.
  const listM = list.map((s) => ({ ...s, menunggu: menungguMap.has(s.id) }));
  const [mapAbsen, hariDihitung] = await Promise.all([
    ambilAgregatSemester(tapel, semester, ids),
    // Hanya siswa yang punya tanggal pindah/jeda/hari Menunggu yang perlu dihitung per siswa; sisanya = hari efektif penuh
    // (totalHariEfektif yang sudah ada) — hasilnya identik (dites), tetapi menghemat satu pemindaian absensi.
    petaHariDihitung(tapel, semester, listM.filter(perluHitungPerSiswa).map((s) => s.id)),
  ]);

  const rows: RekapHistoryRow[] = listM.map((s) => {
    const m = mapAbsen.get(s.id) ?? {};
    const hadir = m.hadir ?? 0;
    const telat = m.terlambat ?? 0;
    const izin = m.izin ?? 0;
    const sakit = m.sakit ?? 0;
    const alpha = m.alpha ?? 0;
    const penyebut = penyebutSiswa(s, hariDihitung, totalHariEfektif);
    const persen = penyebut > 0 ? Math.round(((hadir + telat) / penyebut) * 1000) / 10 : 0;
    return { nama: s.name, kelas: s.class, nisn: s.nisn, labelKeluar: s.labelKeluar, hadir, telat, izin, sakit, alpha, persen };
  });

  return { rows, totalHariEfektif, totalSiswa, totalPages, page: pageAman };
}

/**
 * CATATAN: fungsi di bawah ini menarik SEMUA siswa hasil filter sekaligus
 * (tanpa batas), jadi khusus dipakai untuk kebutuhan yang memang butuh semua
 * baris sekaligus (export CSV/Excel). Untuk tabel di halaman /rekap-history,
 * pakai getRekapHistoryPage() di atas yang sudah true pagination.
 */
export async function getRekapHistory(
  tapel: string,
  semester: string,
  kelasFilter: string
): Promise<{ rows: RekapHistoryRow[]; totalHariEfektif: number }> {
  if (!tapel || !semester) return { rows: [], totalHariEfektif: 0 };

  const totalHariEfektif = await hitungHariEfektif(tapel, semester);

  const [siswaTapel, jedaMap] = await Promise.all([getSiswaTapel(tapel, kelasFilter), ambilJedaTapel(tapel)]);
  const semua = siswaTapel.map((s) => ({
    id: s.siswa_id,
    name: s.nama,
    class: s.kelas,
    nisn: s.nisn,
    nonaktif_pada: s.nonaktif_pada,
    jeda: jedaMap.get(s.siswa_id) ?? [],
    labelKeluar: labelKeluar(s.alasan_nonaktif, s.nonaktif_pada),
  }));
  if (semua.length === 0) return { rows: [], totalHariEfektif };

  const idsSemua = semua.map((s) => s.id);
  const rs = rentangSemester(tapel, semester);
  const menungguMap = rs ? await ambilMenungguBanyak(idsSemua, rs.dari, rs.sampai) : new Map<number, Set<string>>();
  for (const s of semua) (s as { menunggu?: boolean }).menunggu = menungguMap.has(s.id);
  const [mapAbsen, hariDihitung] = await Promise.all([
    ambilAgregatSemester(tapel, semester, idsSemua),
    petaHariDihitung(tapel, semester, semua.filter(perluHitungPerSiswa).map((s) => s.id)),
  ]);
  const [nonaktifIds, setting] = await Promise.all([ambilNonaktifIds(), getAbsensiSetting()]);
  const list = saringSiswaRekap(semua, {
    tapelRekap: tapel,
    tapelAktif: setting.tapel,
    nonaktifIds,
    adaAbsenIds: new Set(mapAbsen.keys()),
    semesterRekap: semester,
  });
  if (list.length === 0) return { rows: [], totalHariEfektif };

  const rows: RekapHistoryRow[] = list.map((s) => {
    const m = mapAbsen.get(s.id) ?? {};
    const hadir = m.hadir ?? 0;
    const telat = m.terlambat ?? 0;
    const izin = m.izin ?? 0;
    const sakit = m.sakit ?? 0;
    const alpha = m.alpha ?? 0;
    const penyebut = penyebutSiswa(s, hariDihitung, totalHariEfektif);
    const persen = penyebut > 0 ? Math.round(((hadir + telat) / penyebut) * 1000) / 10 : 0;
    return { nama: s.name, kelas: s.class, nisn: s.nisn, labelKeluar: s.labelKeluar, hadir, telat, izin, sakit, alpha, persen };
  });

  return { rows, totalHariEfektif };
}

export interface RekapBulananSiswaResult {
  d: Record<string, StatusBulanan>;
  /** Penjelasan sel "×" (tanggal -> teks). */
  ket: Record<string, string>;
  /** Catatan untuk siswa/orang tua bila ada jeda di bulan ini (bahasa sederhana); kosong bila tidak ada. */
  catatanJeda: string[];
  /** Jumlah hari menunggu persetujuan pengajuan (tidak dihitung) dan catatannya untuk orang tua; kosong bila tidak ada. */
  menunggu: number;
  catatanMenunggu: string | null;
  tglList: string[];
  hadir: number;
  terlambat: number;
  izin: number;
  sakit: number;
  alpha: number;
}

/**
 * Versi khusus 1 siswa dari getRekapBulanan() di atas — dipakai di Portal
 * Siswa. SENGAJA fungsi baru (bukan panggil getRekapBulanan lalu filter satu
 * baris), supaya query absensi cuma narik data siswa itu sendiri, bukan
 * seluruh siswa 1 kelas yang notabene tidak dipakai di sini.
 */
export async function getRekapBulananSiswa(
  siswaId: number,
  bulanYYYYMM: string,
  liburMap: Map<string, string>
): Promise<RekapBulananSiswaResult> {
  const tglList = daftarTanggalBulan(bulanYYYYMM);
  // SATU aturan hitung (utils/rekap-siswa.ts): kartu ringkasan di atas halaman memakai fungsi yang sama.
  const { rekap, jeda, konteks } = await getRekapSiswaRentang(siswaId, tglList, liburMap);

  const ket: Record<string, string> = {};
  for (const tgl of tglList) {
    if (rekap.d[tgl] === "menunggu") ket[tgl] = KET_HARI_MENUNGGU;
    if (rekap.d[tgl] === "nonaktif") {
      const k = ketTidakDihitung(konteks.batasPindah?.get(tapelDariTanggal(tgl)), null, jeda, tgl);
      if (k) ket[tgl] = k;
    }
  }

  return {
    d: rekap.d,
    ket,
    catatanJeda: catatanJedaPortal(jeda, bulanYYYYMM),
    menunggu: rekap.menunggu,
    catatanMenunggu: rekap.menunggu > 0
      ? `${rekap.menunggu} hari menunggu persetujuan guru. Hari-hari ini belum dihitung dan belum dianggap Alpha; hasilnya mengikuti keputusan guru.`
      : null,
    tglList,
    hadir: rekap.hadir,
    terlambat: rekap.terlambat,
    izin: rekap.izin,
    sakit: rekap.sakit,
    alpha: rekap.alpha,
  };
}

export async function getRekapBulanan(
  bulanYYYYMM: string,
  kelasFilter: string,
  liburMap: Map<string, string>
): Promise<{ rows: RekapBulananRow[]; tglList: string[] }> {
  const tglList = daftarTanggalBulan(bulanYYYYMM);
  const ta = `${bulanYYYYMM}-01`;
  const [y, m] = bulanYYYYMM.split("-").map(Number);
  const tk = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); // hari terakhir bulan itu

  const tapel = await tapelUntukBulan(bulanYYYYMM);
  const [siswaTapel, jedaMap] = await Promise.all([getSiswaTapel(tapel, kelasFilter), ambilJedaTapel(tapel)]);
  const semua = siswaTapel.map((s) => ({
    id: s.siswa_id,
    name: s.nama,
    class: s.kelas,
    nonaktif_pada: s.nonaktif_pada,
    alasan: s.alasan_nonaktif,
    jeda: jedaMap.get(s.siswa_id) ?? [],
    labelKeluar: labelKeluar(s.alasan_nonaktif, s.nonaktif_pada),
  }));
  if (semua.length === 0) return { rows: [], tglList };

  const ids = semua.map((s) => s.id);
  // Dipaginasi: satu bulan x >40 siswa sudah melewati batas 1000 baris PostgREST.
  // Tanpa ini baris yang terpotong tampil sebagai "alpha" palsu di rekap.
  const absenRows = await ambilSemua<{ siswa_id: number; tanggal: string; status: string }>((dari, sampai) =>
    supabaseAdmin
      .from("absensi")
      .select("siswa_id, tanggal, status")
      .gte("tanggal", ta)
      .lte("tanggal", tk)
      .in("siswa_id", ids)
      .order("id")
      .range(dari, sampai)
  );

  const am = new Map<number, Map<string, StatusAbsen>>();
  for (const r of absenRows) {
    if (!am.has(r.siswa_id)) am.set(r.siswa_id, new Map());
    am.get(r.siswa_id)!.set(r.tanggal, r.status as StatusAbsen);
  }

  // Siswa yang sudah pindah tampil kalau bulan ini masih ada hari efektif sampai tanggal pindahnya (termasuk),
  // atau punya absensi pada hari efektif bulan ini (bukan Minggu/libur, sama seperti perhitungan rekap).
  const hariEfektif = tglList.filter((t) => !liburMap.has(t));
  const tglEfektif = new Set(hariEfektif);
  const adaAbsenIds = new Set<number>();
  for (const r of absenRows) if (tglEfektif.has(r.tanggal)) adaAbsenIds.add(r.siswa_id);
  const [nonaktifIds, setting] = await Promise.all([ambilNonaktifIds(), getAbsensiSetting()]);
  const list = saringSiswaRekap(semua, {
    tapelRekap: tapel,
    tapelAktif: setting.tapel,
    nonaktifIds,
    adaAbsenIds,
    periode: hariEfektif,
  });
  if (list.length === 0) return { rows: [], tglList };

  const today = todayJakarta();
  // Batas awal = catatan pertama siswa pada tapel bulan itu (migrasi 026): hari sebelumnya tidak dihitung. Sama dengan Portal.
  const idsBulan = list.map((s) => s.id);
  const [mulaiMap, menungguMap] = await Promise.all([
    ambilMulaiBanyak(tapelDariTanggal(`${bulanYYYYMM}-01`), idsBulan),
    ambilMenungguBanyak(idsBulan, tglList[0], tglList[tglList.length - 1]),
  ]);

  const rows: RekapBulananRow[] = list.map((s) => {
    const row: RekapBulananRow = {
      id: s.id,
      nama: s.name,
      kelas: s.class,
      labelKeluar: s.labelKeluar,
      jedaLabel: labelJedaBulan(s.jeda, bulanYYYYMM),
      hadir: 0,
      terlambat: 0,
      izin: 0,
      sakit: 0,
      alpha: 0,
      menunggu: 0,
      d: {},
      ket: {},
    };
    // SATU aturan hitung (utils/rekap-siswa.ts), sama dengan kartu Rekap Bulanan & kartu ringkasan di Portal Siswa.
    // Pada/sesudah tanggal pindah dan di hari jeda sel "nonaktif" dan tidak dihitung, apa pun record-nya
    // (record tidak dihapus; mengubah tanggal pindah mengembalikan hitungan).
    const konteks = { today, libur: liburMap, absensi: am.get(s.id) ?? new Map<string, string>(), nonaktifPada: s.nonaktif_pada, jeda: s.jeda, menunggu: menungguMap.get(s.id), mulai: mulaiMap.get(s.id) ?? null };
    const hasil = hitungRekapSiswa(tglList, konteks);
    row.d = hasil.d;
    row.hadir = hasil.hadir;
    row.terlambat = hasil.terlambat;
    row.izin = hasil.izin;
    row.sakit = hasil.sakit;
    row.alpha = hasil.alpha;
    row.menunggu = hasil.menunggu;
    for (const tgl of tglList) {
      if (hasil.d[tgl] === "menunggu") row.ket[tgl] = KET_HARI_MENUNGGU;
      if (hasil.d[tgl] === "nonaktif") {
        const ket = ketTidakDihitung(s.nonaktif_pada, s.alasan, s.jeda, tgl);
        if (ket) row.ket[tgl] = ket;
      }
    }
    return row;
  });

  return { rows, tglList };
}
