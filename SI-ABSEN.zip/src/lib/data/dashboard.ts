import { ambilNonaktifIds } from "@/lib/data/nonaktif";
import { cache } from "react";
import { unstable_cache } from "next/cache";
import { supabaseAdmin } from "@/lib/supabase/server";
import { addDaysJakarta, hariSingkat, isoWeekday, todayJakarta } from "@/lib/utils/tanggal";
import { semesterDariTanggal, tapelDariTanggal } from "@/lib/utils/tapel";
import { ambilSemua } from "@/lib/utils/ambil-semua";
import { getLiburSet } from "@/lib/data/hari-libur";
import type { AbsensiSetting, RecentScan, StatusAbsen, Student, TrenHarian } from "@/types";

// KATEGORI A (data master, jarang berubah): nama sekolah cuma berubah saat
// admin simpan di halaman Setting. Di-cache pakai tag "settings" supaya bisa
// di-invalidate presisi lewat revalidateTag("settings") di
// simpanInfoSekolahAction, tanpa perlu nunggu time-based expiry.
async function _getNamaSekolah(fallback: string): Promise<string> {
  const { data } = await supabaseAdmin
    .from("settings")
    .select("value")
    .eq("key", "nama_sekolah")
    .maybeSingle();
  return data?.value || fallback;
}
export async function getNamaSekolah(fallback: string): Promise<string> {
  return unstable_cache(_getNamaSekolah, ["nama-sekolah"], { tags: ["settings"] })(fallback);
}

// KATEGORI A: foto user berubah hanya saat user ganti profil (jarang).
// Cache per-username lewat tag supaya invalidation presisi ke user terkait.
async function _getFotoUser(username: string): Promise<string | null> {
  const { data } = await supabaseAdmin
    .from("users")
    .select("foto")
    .eq("username", username)
    .maybeSingle();
  return data?.foto || null;
}
export async function getFotoUser(username: string): Promise<string | null> {
  return unstable_cache(_getFotoUser, ["foto-user"], { tags: [`user-${username}`] })(username);
}

// KATEGORI A: absensi_setting (jam masuk/batas terlambat/dst) cuma berubah
// saat admin simpan di halaman Setting > Jadwal, tapi sebelumnya di-query
// ulang di SETIAP request scan QR (lihat src/lib/data/scan.ts) dan setiap
// buka dashboard. Di-cache dengan tag "absensi-setting", di-invalidate lewat
// revalidateTag di simpanJadwalAction.
async function _getAbsensiSetting(): Promise<AbsensiSetting> {
  const { data } = await supabaseAdmin.from("absensi_setting").select("*").limit(1).maybeSingle();
  return {
    jam_masuk: data?.jam_masuk ?? "07:00:00",
    batas_terlambat: data?.batas_terlambat ?? "07:15:00",
    jam_pulang_mulai: data?.jam_pulang_mulai ?? "11:30:00",
    // Fallback (baris setting belum ada): turunkan dari kalender, bukan tahun yang di-hardcode.
    tapel: data?.tapel ?? tapelDariTanggal(todayJakarta()),
    semester: data?.semester ?? semesterDariTanggal(todayJakarta()),
    durasi_kunci_menit: data?.durasi_kunci_menit ?? 120,
    toleransi_pagi_menit: data?.toleransi_pagi_menit ?? 60,
  };
}
export async function getAbsensiSetting(): Promise<AbsensiSetting> {
  return unstable_cache(_getAbsensiSetting, ["absensi-setting"], { tags: ["absensi-setting"] })();
}

export async function cekHariLibur(
  today: string
): Promise<{ isLibur: boolean; pesanLibur: string }> {
  // Minggu selalu libur
  const d = new Date(`${today}T00:00:00Z`);
  if (d.getUTCDay() === 0) {
    return { isLibur: true, pesanLibur: "Libur Akhir Pekan (Minggu)" };
  }

  const { data } = await supabaseAdmin
    .from("hari_libur")
    .select("keterangan")
    .eq("tanggal", today)
    .maybeSingle();

  if (data) return { isLibur: true, pesanLibur: data.keterangan };
  return { isLibur: false, pesanLibur: "" };
}

export interface StatHariIni {
  hadir: number;
  terlambat: number;
  izin: number;
  sakit: number;
  alpha: number;
}

/**
 * TEMUAN AUDIT #4: getStatistikHariIni, getTren7Hari, getRecentScans, dan
 * getBelumAbsen masing-masing tadinya menjalankan query terpisah ke tabel
 * "students" dengan filter kelas yang SAMA persis, walau dipanggil bersamaan
 * lewat Promise.all di dashboard/page.tsx — untuk role guru, 1x buka
 * dashboard = sampai 4 query redundan ke "students".
 *
 * Dibungkus React cache() supaya di-memoize PER REQUEST (bukan cache lintas
 * request seperti data master lain di file ini) — begitu salah satu fungsi
 * di bawah memanggilnya duluan, panggilan berikutnya di request yang sama
 * otomatis reuse hasilnya tanpa query Supabase kedua/ketiga/keempat kali.
 */
const getSiswaKelasUntukDashboard = cache(async (kelas: string, isAdmin: boolean) => {
  if (isAdmin || !kelas) return null;
  const { data } = await supabaseAdmin.from("students").select("id, name, class, foto").eq("class", kelas).eq("status", "aktif");
  return data ?? [];
});

/** Ambil total siswa (opsional filter kelas untuk guru) & statistik status hari ini. */
export async function getStatistikHariIni(
  today: string,
  kelas: string,
  isAdmin: boolean
): Promise<{ totalSiswa: number; stat: StatHariIni }> {
  const siswaKelas = await getSiswaKelasUntukDashboard(kelas, isAdmin);
  const studentIds = siswaKelas ? siswaKelas.map((s) => s.id) : null;

  let totalSiswa: number;
  if (studentIds) {
    totalSiswa = studentIds.length;
  } else {
    const { count } = await supabaseAdmin.from("students").select("id", { count: "exact", head: true }).eq("status", "aktif");
    totalSiswa = count ?? 0;
  }

  // Populasi dashboard = siswa AKTIF (sama dengan totalSiswa). Record milik siswa yang sudah pindah/lulus
  // (mis. alpha otomatis yang terlanjur dibuat) tidak ikut, supaya angkanya tidak bertentangan.
  // Untuk guru, studentIds sudah hanya berisi siswa aktif kelasnya.
  const nonaktif = studentIds ? null : await ambilNonaktifIds();
  const rows = await ambilSemua<{ siswa_id: number; status: string }>((dari, sampai) => {
    let q = supabaseAdmin.from("absensi").select("siswa_id, status").eq("tanggal", today);
    if (studentIds) q = q.in("siswa_id", studentIds);
    return q.order("id").range(dari, sampai);
  });

  const stat: StatHariIni = { hadir: 0, terlambat: 0, izin: 0, sakit: 0, alpha: 0 };
  for (const r of rows) {
    if (nonaktif?.has(r.siswa_id)) continue;
    const st = (r.status as StatusAbsen)?.toLowerCase() as keyof StatHariIni;
    if (st in stat) stat[st]++;
  }

  return { totalSiswa, stat };
}

/** Tren kehadiran (hadir+terlambat) 7 hari terakhir. */
export async function getTren7Hari(
  today: string,
  kelas: string,
  isAdmin: boolean,
  totalSiswa: number
): Promise<TrenHarian[]> {
  const siswaKelas = await getSiswaKelasUntukDashboard(kelas, isAdmin);
  const studentIds = siswaKelas ? siswaKelas.map((s) => s.id) : null;

  const mulai = addDaysJakarta(today, -6);
  // Dipaginasi: 7 hari x >140 siswa melewati batas 1000 baris PostgREST. Populasi = siswa aktif
  // (pembilang dan penyebut `total` sama-sama tanpa siswa yang sudah pindah/lulus).
  const nonaktifIds = studentIds ? null : await ambilNonaktifIds();
  const [semuaRows, liburSet] = await Promise.all([
    ambilSemua<{ siswa_id: number; tanggal: string; status: string }>((dari, sampai) => {
      let query = supabaseAdmin
        .from("absensi")
        .select("siswa_id, tanggal, status")
        .gte("tanggal", mulai)
        .lte("tanggal", today)
        .in("status", ["hadir", "terlambat"]);
      if (studentIds) query = query.in("siswa_id", studentIds);
      return query.order("id").range(dari, sampai);
    }),
    getLiburSet(mulai, today),
  ]);

  const rows = nonaktifIds ? semuaRows.filter((r) => !nonaktifIds.has(r.siswa_id)) : semuaRows;
  const perTanggal = new Map<string, number>();
  for (const r of rows) {
    perTanggal.set(r.tanggal, (perTanggal.get(r.tanggal) ?? 0) + 1);
  }

  const tren: TrenHarian[] = [];
  for (let i = 6; i >= 0; i--) {
    const tgl = addDaysJakarta(today, -i);
    const libur = isoWeekday(tgl) === 7 || liburSet.has(tgl);
    tren.push({
      tgl: hariSingkat(tgl),
      n: libur ? 0 : perTanggal.get(tgl) ?? 0,
      total: totalSiswa,
      isToday: i === 0,
      libur,
    });
  }
  return tren;
}

/** 6 aktivitas absen terbaru hari ini (selain alpha). */
export async function getRecentScans(today: string, kelas: string, isAdmin: boolean): Promise<RecentScan[]> {
  const siswaKelas = await getSiswaKelasUntukDashboard(kelas, isAdmin);
  const studentIds = siswaKelas ? siswaKelas.map((s) => s.id) : null;

  let query = supabaseAdmin
    .from("absensi")
    .select("jam_masuk, status, created_at, students(name, class, foto)")
    .eq("tanggal", today)
    .neq("status", "alpha")
    .order("created_at", { ascending: false })
    .limit(6);
  if (studentIds) query = query.in("siswa_id", studentIds);
  const { data } = await query;

  return (data ?? []).map((r) => {
    // Supabase JS mengembalikan relasi 1-1 sebagai objek (atau array tergantung FK);
    // handle keduanya biar aman.
    const s = Array.isArray(r.students) ? r.students[0] : r.students;
    return {
      jam_masuk: r.jam_masuk,
      status: r.status as StatusAbsen,
      created_at: r.created_at,
      name: s?.name ?? "-",
      class: s?.class ?? "-",
      foto: s?.foto ?? null,
    };
  });
}

/** Siswa yang belum ada record absensi hari ini (maks 8, untuk kartu "Perlu Perhatian"). */
export async function getBelumAbsen(
  today: string,
  kelas: string,
  isAdmin: boolean
): Promise<{ belum: Student[]; belumRecord: number }> {
  const siswaKelas = await getSiswaKelasUntukDashboard(kelas, isAdmin);
  let students: Student[];
  if (siswaKelas) {
    students = [...siswaKelas].sort((a, b) => a.class.localeCompare(b.class) || a.name.localeCompare(b.name));
  } else {
    const { data: allStudents } = await supabaseAdmin
      .from("students")
      .select("id, name, class, foto")
      .eq("status", "aktif")
      .order("class")
      .order("name");
    students = allStudents ?? [];
  }

  const { data: absenRows } = await supabaseAdmin
    .from("absensi")
    .select("siswa_id")
    .eq("tanggal", today);
  const sudahAbsenIds = new Set((absenRows ?? []).map((r) => r.siswa_id));

  const belumSemua = students.filter((s) => !sudahAbsenIds.has(s.id));
  return { belum: belumSemua.slice(0, 8), belumRecord: belumSemua.length };
}
