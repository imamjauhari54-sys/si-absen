import { after, NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { supabaseAdmin } from "@/lib/supabase/server";
import { todayJakarta } from "@/lib/utils/tanggal";
import { kirimNotifAlphaMassal } from "@/lib/wa/notifikasi";
import { KETERANGAN_ALPHA_SISTEM } from "@/lib/utils/absen-scan";

// Notifikasi WA dikirim di after() setelah respons; beri waktu cukup untuk banyak siswa.
export const maxDuration = 60;

/**
 * Diakses dengan salah satu dari dua cara:
 * 1. Session admin lewat tombol manual di dashboard (method POST).
 * 2. Vercel Cron (lihat vercel.json) — Vercel SELALU memanggil cron pakai
 *    method GET, bukan POST, dan menyertakan header
 *    "Authorization: Bearer <CRON_SECRET>" secara otomatis kalau env var
 *    CRON_SECRET diisi di Vercel project settings.
 * CRON_SECRET wajib diisi di .env untuk mengaktifkan jalur kedua ini —
 * kalau kosong, hanya session admin yang bisa memicu endpoint ini.
 */
function isCronAuthorized(req: NextRequest): boolean {
  const cronSecret = process.env.CRON_SECRET;
  if (!cronSecret) return false;
  const auth = req.headers.get("authorization") || "";
  return auth === `Bearer ${cronSecret}`;
}

async function prosesAutoAlpha(req: NextRequest) {
  const session = await getSession();
  const isAdminSession = !!session && session.role === "admin";
  const isCron = isCronAuthorized(req);

  if (!isAdminSession && !isCron) {
    return NextResponse.json({ status: "error", message: "Akses ditolak!" }, { status: 403 });
  }

  const today = todayJakarta();

  // Hari Minggu
  const d = new Date(`${today}T00:00:00Z`);
  if (d.getUTCDay() === 0) {
    return NextResponse.json({ status: "error", message: "Hari ini adalah hari Minggu!" });
  }

  // Hari libur
  const { data: libur } = await supabaseAdmin
    .from("hari_libur")
    .select("id")
    .eq("tanggal", today)
    .maybeSingle();
  if (libur) {
    return NextResponse.json({ status: "error", message: "Hari ini adalah hari libur sekolah!" });
  }

  // Setting tapel & semester
  const { data: setting } = await supabaseAdmin
    .from("absensi_setting")
    .select("tapel, semester")
    .limit(1)
    .maybeSingle();
  if (!setting) {
    return NextResponse.json({ status: "error", message: "Pengaturan Tahun Pelajaran belum diatur!" });
  }

  // Pengajuan izin/sakit orang tua (migrasi 027), SEBELUM membaca/menulis absensi hari ini:
  //  - pengajuan yang sudah DISETUJUI untuk hari ini ditulis sebagai izin/sakit (hanya bila siswa tidak scan; scan menang);
  //  - siswa dengan pengajuan MENUNGGU hari ini TIDAK ditulis Alpha dan TIDAK dikirimi WA Alpha. Bila nanti ditolak/dibatalkan,
  //    Alpha dievaluasi ulang oleh database (evaluasi_alpha_pengajuan).
  // Gagal TERTUTUP: bila pemrosesan pengajuan error (selain fitur belum terpasang), tidak ada Alpha/WA yang dikirim.
  let ditunda = new Set<number>();
  let dariPengajuan = 0;
  const { data: hasilPengajuan, error: galatPengajuan } = await supabaseAdmin.rpc("terapkan_rencana_pengajuan", { p_tanggal: today });
  if (galatPengajuan) {
    if (galatPengajuan.code !== "PGRST202") {
      return NextResponse.json(
        { status: "error", message: `Gagal memproses pengajuan izin/sakit: ${galatPengajuan.message}. Alpha otomatis ditunda.` },
        { status: 500 }
      );
    }
  } else {
    const h = hasilPengajuan as { ditulis?: number; menunggu?: number[] } | null;
    ditunda = new Set(h?.menunggu ?? []);
    dariPengajuan = h?.ditulis ?? 0;
  }

  // Siswa yang belum absen hari ini (izin/sakit dari pengajuan yang baru ditulis di atas sudah terhitung sebagai tercatat)
  const { data: allStudents } = await supabaseAdmin.from("students").select("id, name, class").eq("status", "aktif");
  const { data: absenRows } = await supabaseAdmin.from("absensi").select("siswa_id").eq("tanggal", today);
  const sudahIds = new Set((absenRows ?? []).map((r) => r.siswa_id));
  const belum = (allStudents ?? []).filter((s) => !sudahIds.has(s.id) && !ditunda.has(s.id));
  const jumlahDitunda = (allStudents ?? []).filter((s) => !sudahIds.has(s.id) && ditunda.has(s.id)).length;

  if (belum.length > 0) {
    const rows = belum.map((s) => ({
      siswa_id: s.id,
      tanggal: today,
      status: "alpha",
      keterangan: KETERANGAN_ALPHA_SISTEM,
      tapel: setting.tapel,
      semester: setting.semester,
      scan_oleh: "admin",
    }));
    const { error } = await supabaseAdmin
      .from("absensi")
      .upsert(rows, { onConflict: "siswa_id,tanggal", ignoreDuplicates: true });
    if (error) {
      return NextResponse.json({ status: "error", message: error.message }, { status: 500 });
    }
    // Dijalankan setelah respons dikirim (after) — tanpa ini eksekusi serverless bisa
    // dibekukan dan notifikasi hilang. Dikirim SETELAH baris alpha selesai ditulis (upsert di atas).
    // Seluruh daftar diserahkan sekaligus: Fonnte menerima batch dengan jeda acak antar pesan,
    // gateway lain tetap dikirim per kelompok kecil. Hanya jalan kalau jenis "Alpha" diaktifkan admin.
    after(async () => {
      await kirimNotifAlphaMassal(
        belum.map((s) => ({ id: s.id, name: s.name, class: s.class })),
        today
      );
    });
  }

  const tambahan =
    (jumlahDitunda > 0 ? ` ${jumlahDitunda} siswa ditunda karena pengajuan izin/sakitnya menunggu persetujuan.` : "") +
    (dariPengajuan > 0 ? ` ${dariPengajuan} izin/sakit dari pengajuan yang disetujui dicatat.` : "");
  return NextResponse.json({
    status: "ok",
    message: `Berhasil memproses ${belum.length} siswa menjadi Alpha.${tambahan}`,
    alpha: belum.length,
    ditunda: jumlahDitunda,
    dariPengajuan,
  });
}

// Vercel Cron selalu memanggil pakai GET (lihat vercel.json)
export async function GET(req: NextRequest) {
  return prosesAutoAlpha(req);
}

// Tombol manual admin di dashboard memanggil pakai POST
export async function POST(req: NextRequest) {
  return prosesAutoAlpha(req);
}
