import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { getBatasKelas } from "@/lib/auth/akses-kelas";
import { supabaseAdmin } from "@/lib/supabase/server";
import { daftarTanggalBulan, getRekapBulanan, getRekapHarian } from "@/lib/data/rekap";
import { getHariLiburMap } from "@/lib/data/hari-libur";

function csvEscape(val: string): string {
  if (/[",\n]/.test(val)) return `"${val.replace(/"/g, '""')}"`;
  return val;
}
function toCsvLine(fields: (string | number)[]): string {
  return fields.map((f) => csvEscape(String(f))).join(",") + "\r\n";
}

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { searchParams } = req.nextUrl;
  const view = searchParams.get("view") === "bulanan" ? "bulanan" : "harian";
  const batas = await getBatasKelas(session);
  if (!batas.semua && !batas.kelas) return NextResponse.json({ message: "Akses ditolak" }, { status: 403 });
  const kelasFilter = batas.semua ? searchParams.get("kelas") ?? "" : batas.kelas!;

  let csv = "\uFEFF";
  csv += "sep=,\r\n";
  let filenameSuffix: string;

  if (view === "harian") {
    const tanggal = searchParams.get("tgl") ?? "";
    filenameSuffix = tanggal;
    csv += toCsvLine(["Nama Siswa", "Kelas", "NISN", "Status", "Jam Masuk", "Jam Pulang", "Keterangan"]);

    const { rows } = await getRekapHarian(tanggal, kelasFilter);
    // NISN tidak ikut dipilih di getRekapHarian, ambil terpisah biar ringan
    const { data: nisnRows } = await supabaseAdmin.from("students").select("id, nisn");
    const nisnMap = new Map((nisnRows ?? []).map((r) => [r.id, r.nisn]));

    for (const r of rows) {
      const statusReal = r.status === "kosong" ? "alpha" : r.status;
      // Tanggal pindah siswa: baris ikut diekspor tetapi tidak dihitung (bukan alpha).
      // Libur dan "belum tercatat" (sebelum catatan pertama siswa) juga TIDAK diekspor sebagai Alpha (aturan baseline).
      const labelStatus = r.libur
        ? "Libur"
        : r.menunggu
          ? "Menunggu persetujuan"
        : r.belumTercatat
          ? "Belum tercatat"
          : r.tidakDihitung
            ? "Tidak dihitung" + (r.labelKeluar ? ` (${r.labelKeluar})` : "")
            : statusReal.charAt(0).toUpperCase() + statusReal.slice(1);
      csv += toCsvLine([
        r.name,
        r.class,
        "'" + (nisnMap.get(r.id) ?? ""),
        labelStatus,
        r.jam_masuk ? r.jam_masuk.slice(0, 5) : "-",
        r.jam_pulang ? r.jam_pulang.slice(0, 5) : "-",
        r.keterangan ?? "",
      ]);
    }
  } else {
    const bulan = searchParams.get("bulan") ?? "";
    filenameSuffix = bulan;
    const liburMap = await getHariLiburMap();
    const tglList = daftarTanggalBulan(bulan);

    const header = ["Nama Siswa", "Kelas", ...tglList.map((t) => t.slice(8, 10)), "H", "T", "I", "S", "A", "Catatan"];
    csv += toCsvLine(header);

    const { rows } = await getRekapBulanan(bulan, kelasFilter, liburMap);
    for (const row of rows) {
      const cells = tglList.map((t) => {
        const st = row.d[t];
        // "kosong" = hari ini/mendatang yang belum punya catatan: dikosongkan, BUKAN Alpha (dulu terekspor "A" dan ikut dihitung).
        return st === "libur" ? "L" : st === "nonaktif" ? "-" : st === "menunggu" ? "M" : st === "kosong" ? "" : st.charAt(0).toUpperCase();
      });
      const sum = { H: 0, T: 0, I: 0, S: 0, A: 0 };
      for (const c of cells) if (c in sum) sum[c as keyof typeof sum]++;
      // "-" = tidak dihitung (pindah/jeda), BUKAN alpha: dijelaskan di kolom Catatan supaya tidak disangka data hilang.
      const catatan = [row.labelKeluar, row.jedaLabel, row.menunggu > 0 ? `${row.menunggu} hari menunggu persetujuan (M)` : ""].filter(Boolean).join("; ");
      csv += toCsvLine([row.nama, row.kelas, ...cells, sum.H, sum.T, sum.I, sum.S, sum.A, catatan]);
    }
  }

  return new NextResponse(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="rekap_${view}_${filenameSuffix}.csv"`,
    },
  });
}
